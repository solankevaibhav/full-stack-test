using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;
namespace Crud
{
    #region Vaibhav
    public class Vaibhav
    {
        #region Member Variables
        protected int _id;
        protected string _name;
        protected string _password;
        protected string _email;
        #endregion
        #region Constructors
        public Vaibhav() { }
        public Vaibhav(string name, string password, string email)
        {
            this._name=name;
            this._password=password;
            this._email=email;
        }
        #endregion
        #region Public Properties
        public virtual int Id
        {
            get {return _id;}
            set {_id=value;}
        }
        public virtual string Name
        {
            get {return _name;}
            set {_name=value;}
        }
        public virtual string Password
        {
            get {return _password;}
            set {_password=value;}
        }
        public virtual string Email
        {
            get {return _email;}
            set {_email=value;}
        }
        #endregion
    }
    #endregion
}
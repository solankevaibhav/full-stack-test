<?php
    include('basic/connect.php'); 

    if(isset($_GET['id']))
    {
        $id = $_GET['id'];
        $sql_delete = "DELETE FROM `vaibhav` WHERE id='$id'";
        
        if($conn->query($sql_delete) === TRUE)
        {
            echo "<script>alert('Record Deleted Successfully...!')</script>";
        }
        else
        {
            echo "<script>alert('Fail To Delete...!')</script>";
        }
        echo "<script>window.location='user.php';</script>";
    }
?>
<!DOCTYPE html>
<html>
    <head>
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
                <title>Database-Bootstrap</title>
                <meta name="viewport" content="width=device-width, initial-scale=1">
                <link rel="stylesheet" href="css/bootstrap.min.css">
                <script src="js/jquery.min.js"></script>
                <script src="js/bootstrap.min.js"></script>
		<link href="css/style.css" rel="stylesheet" type="text/css" />
                <script src="js/jquery.min.js"></script>
                <script src="js/jquery-1.11.1.min.js"></script>
                  <script src="js/jquery.validate.js"></script>
                <link rel="stylesheet" href="css/font-awesome.css">
		<meta content="First-Sample Task" name="description" />
		<meta name="keywords" content="First-Sample" />
                <meta name="author" content="" />
    </head>
    <body>
        <div class="spacing">
            <nav class="navbar navbar-inverse navbar-fixed-top">
                <div class="container no-padding">
                    <div class="navbar-header">
                        <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
                          <span class="icon-bar"></span>
                          <span class="icon-bar"></span>
                          <span class="icon-bar"></span>                        
                        </button>
                    </div>
                     <div class="collapse navbar-collapse no-padding" id="myNavbar" >
                        <ul class="nav navbar-nav">
                            <li><a href="index.php" class="side-bar"><b>Home</b></a></li>
                          <li><a href="about-us.php" class="side-bar">About us</a></li>
                          <li><a href="user.php" class="side-bar">Freight</a></li>
                          <li><a href="#" class="side-bar">FAQ's</a></li>
                          <li><a href="contact-us.php">Contact</a></li>
                        </ul>
                        <ul class="nav navbar-nav navbar-right">
                          <li><a href="#" class="side-bar">Call us: +27 (0)21 531 1854</a></li>
                          <li><a href="#">Basket&nbsp;&nbsp;<i class="fa fa-shopping-basket" aria-hidden="true"></i></a></li>
                          <li><a href="#" class="nav-login btn">Login</a></li>
                          <li><a href="#" class="light-blue btn register launch-modal">Register</a></li>
                          <li>
                              <div class="dropdown">
                                <a class="btn dropdown-toggle" role="button" data-toggle="dropdown">
                                <span><i class="fa fa-share-alt" aria-hidden="true"></i></span></a>
                                <ul class="dropdown-menu icon-size mid-bg">
                                    <li class="text-center"><i class="fa fa-facebook"></i></li>
                                    <li class="text-center"><i class="fa fa-whatsapp"></i></li>
                                    <li class="text-center"><i class="fa fa-twitter" aria-hidden="true"></i></li>
                                    <li class="text-center"><i class="fa fa-linkedin" aria-hidden="true"></i></li>
                                    <li class="text-center"><i class="fa fa-envelope" aria-hidden="true"></i></li>
                                </ul>
                              </div>
                          </li>
                        </ul>
                    </div>
                </div>
              </nav>
        </div>
  
       
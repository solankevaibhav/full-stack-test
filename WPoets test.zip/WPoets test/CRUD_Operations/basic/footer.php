 <div class="jumbotron top-spacing-footer">
            <div class="container no-padding">
                <div class="footer-box">
                <nav class="navbar footer-nav">
                    <div class="container-fluid no-padding">
                      <ul class="nav navbar-nav third-navbar">
                          <li><a href="about-us.php">About us</a></li>
                        <li><a href="#">Terms</a></li>
                        <li><a href="#">Privacy Policy</a></li>
                        <li><a href="#">FAQ's</a></li>
                        <li><a href="contact-us.php">Contact</a></li>
                      </ul>
                        <ul class="nav navbar-nav navbar-right third-navbar">
                        <li><a href="#">+27 (0)21 531 1185</a></li>
                      </ul>
                    </div>
                </nav>
                    <div class="line margin-non"></div>
                    <div class="row font-color footer-space">
                        <div class="col-md-9 no-padding">
                            <div class="row">
                                <div class="col-md-7 no-padding">Copyright &copy; 2017 TerraBrands. All Rights Reserved.</div>
                                <div class="col-md-5 no-padding">Website Design : monzamedia</div>
                            </div>
                        </div>
                        <div class="col-md-3 twitter-center"><div class="twitter twitter-pull-right pull-right"><i class="fa fa-twitter twitter-img "></i></div></div>
                    </div>
                </div>
            </div>
        </div>
        
         <!-- Modal -->
        <div class="modal fade" id="login-form" role="dialog">
          <div class="modal-dialog modal-sm">
            <div class="modal-content">
              <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                <h4 class="modal-title">Login Form</h4>
              </div>
                <form class="form-horizontal" id="signin-form" action="login_db.php" method="post">
                    <div class="modal-body">
                            <div class="form-group">
                                <label class="control-label col-sm-4" for="name">Username:</label>
                                <div class="col-sm-7">
                                    <input type="text" class="form-control" id="username" placeholder="Username" name="username">
                                    <div id="error-name"></div>
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="control-label col-sm-4" for="name">Password:</label>
                                <div class="col-sm-7">
                                    <input type="password" class="form-control" id="password" placeholder="Password" name="password" value="<?php if(isset($_COOKIE['my_password'])){ echo $_COOKIE['my_password']; } ?>">  
                                    <div id="error-password"></div>
                                </div>
                            </div>
                        <div class="form-group">
                            <div class="control-lebel col-sm-12">
                                                    <label><input type="checkbox" name="remember"> Remember me</label>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="submit" class="btn btn-default" id="set-value">Set</button>
                        <button type="submit" name="submit" onclick="submit_login()" class="btn btn-default">Submit</button>
                      <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                    </div>
              </form>
            </div>
          </div>
        </div>
      
        <!-- Modal -->
        <div class="modal fade" id="register-form" role="dialog">
          <div class="modal-dialog modal-sm">
            <div class="modal-content">
              <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                <h4 class="modal-title">Register Form</h4>
              </div>
             
                       <div class="modal-body">
                                            <form class="form-horizontal" id="signup-form" action="registration_db.php" method="post">

                      <div class="form-group">
                          <label class="control-label col-sm-5" for="name">Username:</label>
                          <div class="col-sm-6">
                              <input type="text" class="form-control"  placeholder="Username" id="name" name="username">
                              <div id="error_username"></div>
                          </div>
                      </div>
                      <div class="form-group">
                          <label class="control-label col-sm-5" for="name">New Password:</label>
                          <div class="col-sm-6">
                              <input type="password" class="form-control"  placeholder="New Password" id="new_password" name="password">
                              <div id="error_new_password"></div>
                          </div>
                      </div>
                       <div class="form-group">
                          <label class="control-label col-sm-5" for="name">Confirm Password:</label>
                          <div class="col-sm-6">
                              <input type="password" class="form-control"  placeholder="Confirm Password" id="confirm_password" name="confirmpassword">
                              <div id="error_confirm_password"></div>
                          </div>
                      </div>
                        <div class="form-group">
                          <label class="control-label col-sm-5" for="name">Gender:</label>
                          <div class="col-sm-6">
                              <input type="radio" class="form-check-input" id="female" name="gender" value="female"> Female&nbsp;&nbsp;
                              <input type="radio" class="form-check-input" id="male" name="gender" value="male"> Male
                              <div id="error_gender"></div>
                          </div>
                      </div>
                     <div class="form-group">
                          <label class="control-label col-sm-5" for="name">18+:</label>
                          <div class="col-sm-6">
                              <label class="switch" id="age">
                                <input type="checkbox" name="eighteenplus" value="1">
                                <span class="slider round"></span>
                               </label>
                          </div>
                      </div>
                      <div class="form-group">
                          <label class="control-label col-sm-5" for="name">Birth Date:</label>
                          <div class="col-sm-6">
                              <input type="date" class="form-control" id="bod" placeholder="Birth Date" name="dateofbirth">
                          </div>
                      </div>
                      <div class="form-group">
                          <label class="control-label col-sm-5" for="name">Education:</label>
                          <div class="col-sm-6">
                              <select class="form-control" id="education" name="education">
                                <option value="none">---Select Degree---</option>
                                <option value="b.sc.(computer science)">B.Sc(computer science)</option>
                                <option value="m.sc.(computer science)">M.Sc(computer science)</option>
                                <option value="b.sc.(botany)">B.Sc(Botany)</option>
                            </select>
                          </div>
                      </div>
                      <div class="form-group">
                          <label class="control-label col-sm-5" for="name">Short Note:</label>
                          <div class="col-sm-6">
                              <textarea class="form-control" rows="5" id="note" name="note" placeholder="Short Note"></textarea>
                              <div class="error_note"></div>
                          </div>
                      </div>
                      <div class="form-group">
                          <div class="col-sm-12">
                              <div class="col-sm-offset-2 ">
                                <input type="checkbox" class="form-check-input" id="check1" name="condition"> Terms and Condition Apply*
                              </div>
                          </div>
                          <div class="col-sm-12">
                              <div class="progress">
                    <div class="progress-bar progress-bar-striped active" role="progressbar" aria-valuenow="60" aria-valuemin="0" aria-valuemax="100">
                      80%
                    </div>
                  </div>
                 </div>
                 </div>
                                                <div class="modal-footer">
                  <button id="set-reg" class="btn btn-default" >Set</button>
                  <button type="submit"name="submit" class="btn btn-default" onclick="register_form()">Submit</button>
                <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
              </div>
                                                 </form>
                 </div>
              
            
          
            </div>
          </div>
        </div>
      
        <div class="modal fade" id="light-box-1" role="dialog">
            <div class="modal-dialog modal-md">
              <div class="modal-content">
               
                <div class="modal-body">
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                    <img src="images/categories/img-1.jpg" class="img-responsive light-box-img" >
                </div>
                
              </div>
            </div>
          </div>
        
        <div class="modal fade" id="light-box-2" role="dialog">
            <div class="modal-dialog modal-md">
              <div class="modal-content">
               
                <div class="modal-body">
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                    <img src="images/categories/img-2.jpg" class="img-responsive light-box-img" >
                </div>
                
              </div>
            </div>
          </div>
        
        <div class="modal fade" id="light-box-3" role="dialog">
            <div class="modal-dialog modal-md">
              <div class="modal-content">
               
                <div class="modal-body">
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                    <img src="images/categories/img-3.jpg" class="img-responsive light-box-img" >
                </div>
                
              </div>
            </div>
          </div>
        
        <div class="modal fade" id="light-box-4" role="dialog">
            <div class="modal-dialog modal-md">
              <div class="modal-content">
               
                <div class="modal-body">
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                    <img src="images/categories/img-4.jpg" class="img-responsive light-box-img" >
                </div>
                
              </div>
            </div>
          </div>
        
        <div class="modal fade" id="light-box-5" role="dialog">
            <div class="modal-dialog modal-md">
              <div class="modal-content">
               
                <div class="modal-body">
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                    <img src="images/categories/img-5.jpg" class="img-responsive light-box-img" >
                </div>
                
              </div>
            </div>
          </div>
        
        <div class="modal fade" id="light-box-6" role="dialog">
            <div class="modal-dialog modal-md">
              <div class="modal-content">
               
                <div class="modal-body">
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                    <img src="images/categories/img-6.jpg" class="img-responsive light-box-img" >
                </div>
                
              </div>
            </div>
          </div>
        <script src="js/jquery.min.js"></script>
        <script src="js/bootstrap.min.js"></script>
        <script src="js/validation.js"></script>
        <script>
            $(document).ready(function(){
               $("#btn_change").click(function(){
                  $(".box-border").css("border-color","#ff0000");
               });
               
               $("#btn_hide").click(function(){
                  $(".category-title").text("Text Hided!");
               });
               
               $("#btn_append").click(function(){
                  $(".append-img").append("<div class='col-md-4 img-frame'>\
                    <div class='col-md-12 box-border no-padding mx-auto'>\
                    <a href='#' class='category-cursor' data-toggle='modal' data-target='#light-box-4'>\
                    <img src='images/categories/img-4.jpg' class='img-responsive auto-margin img-height'>\
                    <div class='text-center content-title'><h4 class='category-title'>PANTS, SKIRTS AND BELTS</h4></div>\
                    </a>\
                    </div>\
                    </div>");
               });
            });
        </script>
        <script>
            $(document).ready(function () {
        $("#signup-form").validate({
           
            rules: {
               username: {
                    required: true
                },
             
              password:{
                    required: true
                    
                     },
                confirmpassword:{
                    required:true
                },
               gender:{
                    required:true
                },
                eighteenplus:{
                    required:true
                },
                dateofbirth:{
                    required:true
                },
                education:{
                    required:true
                },
                note:{
                    required:true
                }
                
            }, 
                messages:{
                username: "Please Enter First Username",
              password: "Please  Enter valid Password",
               confirmpassword:"please again enter your password",
                gender:"please Choose gender",
              eighteenplus:"please press switcher ",
              dateofbirth:"please select your DOB",
               education:"please select Education ",
                note:"please Enter text "
                
                },
                submitHandler: function (form) {
                //formdata = $("#registration").serialize();
            }
            });
             });
            </script>
        
    </body>
</html>



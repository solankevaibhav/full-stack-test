<?php include('basic/header.php'); 
 if(isset($_COOKIE['my_password']))
    {
        echo "<b>".$_COOKIE['my_password']."<b>";
    }
    ?>
        <div class="container hr"></div>
        <div class="container">
            <div class="row">
                <div class="col-md-12 us-top">
                    <div class="col-md-12 no-padding">
                        <div class="col-md-6 no-padding">
                            <h2>User-Table</h2>
                        </div>
                        <div class="col-md-offset-3 col-md-3 no-padding">
                            <input class="form-control search_space" id="myInput" type="text" placeholder="Search..">
                        </div>
                    </div>
                             
                    <table class="table table-bordered table-striped">
                      <thead>
                        <tr>
                          <th>ID</th>
                          <th>Name</th>
                          <th>Password</th>
                           <th>Email</th>
                          <th>Action</th>
                          
                        </tr>
                      </thead>
                      <?php include('basic/connect.php'); ?>
                      <tbody id="myTable">
                          <?php 
                                $sql_view = "SELECT * FROM  `vaibhav`";
                                $result_view = $conn->query($sql_view);
                                
                                if( $result_view->num_rows > 0 )
                                {
                                    while($row_view = $result_view->fetch_assoc())
                                    {
                                        ?>
                                            <tr>
                                                <td><?php echo $row_view['id']; ?></td>
                                                <td><?php echo $row_view['name']; ?></td>
                                                <td><?php echo $row_view['password']; ?></td>
                                                <td id="user_<?php echo $row_view['id']; ?>"><?php echo $row_view['email']; ?></td>

                                                <td>
                                                    <a href="add.php" class="btn btn-success">Add</a>
                                                    <a href="change.php?id=<?php echo $row_view['id']; ?>" class="btn btn-warning">Update</a>
                                                    <a href="delete.php?id=<?php echo $row_view['id']; ?>" class="btn btn-danger">Delete</a>
                                                    <button type="button" id="email_<?php echo $row_view['id']; ?>" class="btn btn-info send_email" data-toggle="modal" data-target="#myModalEmail">Send Email</button>

                                                </td>
                      
                                            </tr>
                                        <?php
                                    }
                                }
                          ?>
                      </tbody>
                    </table>
         </div>
            </div>
        </div>
        <div class="modal fade" id="myModalEmail" role="dialog">
    <div class="modal-dialog modal-md">
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">Send Email</h4>
        </div>
        <div class="modal-body">
            <form class="form-horizontal" action="email.php" method="post">
            <div class="form-group">
              <label class="control-label col-sm-2" for="email">Email:</label>
              <div class="col-sm-10">
                  <input type="email" class="form-control" id="email" placeholder="Enter email" name="email" readonly>
              </div>
            </div>
            <div class="form-group">
              <label class="control-label col-sm-2" for="pwd">Message:</label>
              <div class="col-sm-10">          
                  <textarea class="form-control" rows="4" cols="4" id="msg" placeholder="Enter password" name="msg"></textarea>
              </div>
            </div>
            <div class="form-group">        
              <div class="col-sm-offset-2 col-sm-10">
                  <button type="submit" name="send_mail" class="btn btn-default">Submit</button>
              </div>
            </div>
          </form>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      </div>
    </div>
  </div>
  
<?php include('basic/footer.php');  ?>
<script>
    $(document).ready(function(){
        $("#myInput").on("keyup", function() {
          var value = $(this).val().toLowerCase();
          $("#myTable tr").filter(function() {
            $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
          });
        });
         $(".send_email").click(function(){
            let email = $(this).attr("id");
            let email_array = email.split("_");
            let user_id = 'user_'+email_array[1];
            
            let email_address = $("#"+user_id).text();
            $("#email").val(email_address);
        });
      });
</script>
        
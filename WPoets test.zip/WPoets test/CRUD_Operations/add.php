<?php include('basic/header.php'); ?>
        <div class="container hr"></div>
        <div class="container">
            <div class="row">
                <div class="col-md-12 us-top">
                    <h2 class="text-center">Add User</h2>         
                      <form class="form-horizontal" action="insert.php" method="post">
                        <div class="form-group">
                          <label class="control-label col-sm-offset-2 col-sm-2" for="name">name:</label>
                          <div class="col-sm-5">
                            <input type="text" class="form-control" id="name" placeholder="Enter name" name="name">
                          </div>
                        </div>
                        
                        <div class="form-group">
                          <label class="control-label col-sm-offset-2 col-sm-2" for="password">Password:</label>
                          <div class="col-sm-5">          
                            <input type="password" class="form-control" id="password" placeholder="Enter password" name="password">
                          </div>
                        </div>
                          <div class="form-group">
                          <label class="control-label col-sm-offset-2 col-sm-2" for="email">Email:</label>
                          <div class="col-sm-5">
                            <input type="email" class="form-control" id="email" placeholder="Enter email" name="email">
                          </div>
                        </div>
                        <div class="form-group">        
                          <div class="text-center">
                            <button type="submit" name="submit" class="btn btn-success">Submit</button>
                          </div>
                        </div>
                      </form>
                </div>
            </div>
        </div>
<?php include('basic/footer.php');  ?>
        
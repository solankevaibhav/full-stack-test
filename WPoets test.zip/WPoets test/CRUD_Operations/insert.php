<?php
    include('basic/connect.php'); 

    if(isset($_POST['submit']))
    {
        $name=$_POST['name'];
        $password=$_POST['password'];
         $email=$_POST['email'];
        $sql_insert = "INSERT INTO `vaibhav`(`name`, `password`,`email` ) VALUES ('$name','$password','$email')";
        
        if($conn->query($sql_insert) === TRUE)
        {
            echo "<script>alert('Record Inserted Successfully...!')</script>";
        }
        else
        {
            echo "<script>alert('Fail To Insert...!')</script>";
        }
        echo "<script>window.location='user.php';</script>";
    }
?>
$(document).ready(function(){
   $('.nav-login').click(function(){
		$('#login-form').modal({
			backdrop: 'static'
                    });
                }); 
                
     $('.launch-modal').click(function(){
		$('#register-form').modal({
			backdrop: 'static'
                    });
                });    
                
                $("#set-value").click(function(){
                  $("#username").val("Komal Thombre");
                  $("#password").val("Komal Thombre");
               });
               
               $("#set-reg").click(function(){
                    $("#name").val("Komal Thombre");
                  $("#new_password").val("Komal Thombre");
                  $("#confirm_password").val("Komal Thombre");
                  $("#register-form").modal("show");
               });
});


function submit_login()
{
    var username = document.getElementById("username").value;
    var password = document.getElementById("password").value;
    
    if(username=="")
    {
        document.getElementById("error-name").innerHTML="<b>Enter Username</b>";
    }
    if(password=="")
    {
        document.getElementById("error-password").innerHTML="<b>Enter Password</b>";
    }
}

function register_form()
{
    var name = document.getElementById("name").value;
    var new_password = document.getElementById("new_password").value;
    var confirm_password = document.getElementById("confirm_password").value;
    var female = document.getElementById("female").checked;
    var male = document.getElementById("male").checked;
   
    
    if(name=="")
    {
        document.getElementById("error_username").innerHTML="<b>Enter Username</b>";
    }
    if(new_password=="")
    {
        document.getElementById("error_new_password").innerHTML="<b>Enter New Password</b>";
    }
    if(confirm_password=="")
    {
        document.getElementById("error_confirm_password").innerHTML="<b>Enter Confirm Password</b>";
    }
    if(female==false && male==false)
    {
        document.getElementById("error_gender").innerHTML="<b>Select Gender</b>";
    }
}

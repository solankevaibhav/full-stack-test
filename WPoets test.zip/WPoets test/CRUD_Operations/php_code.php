<?php
$servername = "localhost";
$username = "root";
$password = "root";
$db="crud";

$conn = new mysqli($servername, $username, $password,$db);
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

$sql = "INSERT INTO vaibhav (id, name, password)
VALUES ('1', 'vaibhav', 'vaibhav_123')";
$sql = "INSERT INTO vaibhav (id, name, password)
VALUES ('2', 'sunil', 'sunil_123')";

if ($conn->query($sql) === TRUE) {
    echo "New record created successfully";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();

?>

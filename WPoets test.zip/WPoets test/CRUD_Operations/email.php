<?php
    if(isset($_POST['send_mail']))
    {
        ini_set("SMTP", "mail.pandoraitsolutions.com");
        ini_set("sendmail_from", "solankevaibhav412@gmail.com");
        $email = $_POST['email'];
        $msg = $_POST['msg'];
        
       $subject = "msg";
       $headers = "From:solankevaibhav412@gmail.com";
       
       mail($email, $subject, $msg,  $headers);
       header('Location:user.php');
    }
?>
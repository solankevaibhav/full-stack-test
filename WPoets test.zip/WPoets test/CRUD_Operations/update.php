<?php
    include('basic/connect.php'); 

    if(isset($_POST['update']))
    {
        $id = $_POST['id'];
        $name=$_POST['name'];
        $password=$_POST['password'];
        $email=$_POST['email'];
        $sql_update = "UPDATE `vaibhav` SET `name`='$name', `password`='$password',`email`='$email'  WHERE `id`='$id'";
        
        if($conn->query($sql_update) === TRUE)
        {
            echo "<script>alert('Record Updated Successfully...!')</script>";
        }
        else
        {
            echo "<script>alert('Fail To Update...!')</script>";
        }
        echo "<script>window.location='user.php';</script>";
    }
?>
<?php 
    include('basic/header.php');
    
?>
        <div class="container hr"></div>
        <div class="container">
            <div class="row">
                <div class="col-md-12 us-top">
                    <h2 class="text-center">Update User</h2>
                        <form class="form-horizontal" action="update.php" method="post">
                        <?php
                            if(isset($_GET['id']))
                            {
                                include('basic/connect.php');
                                $id = $_GET['id'];
                                $sql_fetch = "SELECT * FROM `vaibhav` WHERE id='$id'";
                                $result_fetch = $conn->query($sql_fetch);
                                if($result_fetch->num_rows === 1)
                                {
                                while($row_fetch = $result_fetch->fetch_assoc())
                                {
                                    ?>
                                        <input type="hidden" name="id" value="<?php echo $row_fetch['id']; ?>" >
                                        <div class="form-group">
                                            <label class="control-label col-sm-offset-2 col-sm-2" for="name">name:</label>
                                            <div class="col-sm-5">
                                              <input type="text" class="form-control" id="name" value="<?php echo $row_fetch['name']; ?>" placeholder="Enter name" name="name">
                                            </div>
                                          </div>
                                          
                                          <div class="form-group">
                                            <label class="control-label col-sm-offset-2 col-sm-2" for="password">Password:</label>
                                            <div class="col-sm-5">          
                                                <input type="password" class="form-control" id="password" value="<?php echo $row_fetch['password']; ?>" placeholder="Enter password" name="password">
                                            </div>
                                          </div>
                                        <div class="form-group">
                                            <label class="control-label col-sm-offset-2 col-sm-2" for="email">Email:</label>
                                            <div class="col-sm-5">
                                                <input type="email" class="form-control" value="<?php echo $row_fetch['email']; ?>" id="email" placeholder="Enter email" name="email">
                                            </div>
                                          </div>
                                    <?php
                                }
                                }
                                else
                                {
                                    echo "fail";
                                }
                            }
                        ?>
                        <div class="form-group">        
                          <div class="text-center">
                            <button type="submit" name="update" class="btn btn-success">Update</button>
                          </div>
                        </div>
                      </form>
                </div>
            </div>
        </div>
<?php include('basic/footer.php');  ?>
        